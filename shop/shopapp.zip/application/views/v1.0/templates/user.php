<div class="right links hasloggedin">
	<a href="/user/">megrendeléseim</a> &nbsp;
	<a href="/user/beallitasok">beállítások</a> 
	<span class="divpoint">&nbsp;&bull;&nbsp;</span> 
	<a class="logoutlink" href="/user/logout">kijelentkezés</a>
</div>