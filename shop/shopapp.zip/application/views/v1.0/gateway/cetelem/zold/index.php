<div class="statusmsg stat-done">
	Hitelkérelme előzetesen elfogadásra került!
</div>
<div class="statusdesc">
	<h3>Tisztelt Ügyfelünk!</h3>
	 Köszönjük megtisztelő bizalmát!<br><br>
	 Hiteligénylése a Bank által előzetesen elfogadásra került, így az Ön által megadott adatok alapján elektronikusan előáll a szerződés, melyet a nyomtatás/mentés gombra kattintva számítógépére lementett vagy azonnal ki is nyomtatott.<br>
	 Elfogadás esetén Ön minden esetben kap egy e-mailt is az igénylés során megadott címre, amelyben szereplő linkre kattintva Ön szintén mentheti/nyomtathatja szerződését.
	 <br><br>
	 Probléma merült fel? Hívja az alábbi telefonszámot: <?=$this->settings['page_author_phone']?>
</div>
<br><br>
<a href="/order/<?=$this->gets[3]?>" class="btn btn-default"><i class="fa fa-angle-left"></i> Megrendelés adatlapja</a>