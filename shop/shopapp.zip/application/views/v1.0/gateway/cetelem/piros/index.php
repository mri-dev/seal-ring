<div class="statusmsg stat-cancel">
	Sikertelen hiteligénylés. Kérelem elutasítva.
</div>
<div class="statusdesc">
	<h3>Tisztelt Ügyfelünk!</h3>
	Köszönjük megtisztelő bizalmát!<br><br>
	Feldolgoztuk online áruhitel kérelmét, melyet honlapunkon kezdeményezett.<br>
	Kérelme a megadott adatok alapján elutasításra került. Tájékoztatjuk, hogy a hitelkérelem elutasítására az adatok automatikus feldolgozása során került sor.<br>
</div>
<br><br>
<a href="/order/<?=$this->gets[3]?>" class="btn btn-default"><i class="fa fa-angle-left"></i> Megrendelés adatlapja</a>