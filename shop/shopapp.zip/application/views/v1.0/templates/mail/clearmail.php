<? require "head.php"; ?>
	<?=$content?>
<? require "footer.php"; ?>