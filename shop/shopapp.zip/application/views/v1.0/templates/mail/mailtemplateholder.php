<? require "head.php"; ?>
<?=$mailtemplate?>
<? require "footer.php"; ?>
