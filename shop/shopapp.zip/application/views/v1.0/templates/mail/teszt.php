<? require "head.php"; ?>
Teszt e-mail!
<? require "footer.php"; ?>