<?php if ($nev): ?>
  <?php echo $nev; ?>
<?php endif; ?>
