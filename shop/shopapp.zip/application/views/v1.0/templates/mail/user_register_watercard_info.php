<? require "head.php"; ?>
<h2>Tisztelt Vásárlónk!</h2>
<br>
Köszönjük, hogy regisztrálta <strong>ARENA WATER CARD</strong> kártyáját, amivel <strong>25%-kal kedvezményesebben</strong> vásárolhat webáruházunkból.
<br><br>
<strong style="color:red;">Felhívjuk figyelmét, hogy a kedvezményt a <u>kártya aktiválása után veheti igénybe</u>! A kártya aktiválásakor értesíteni fogjuk e-mail üzenetben, hogy megkapta a kedvezményt!</strong>
<br>
<br>
<br>
További részleteket a kedvezményről <strong><a href="http://www.<?=rtrim(str_replace(array('http://','www.'),array('',''),$settings['page_url']),'/')?>/p/arena_water_card">itt olvashat</a></strong>.
<? require "footer.php"; ?>