<div class="statusmsg stat-inprogress">
	Hitelkérelmének feldolgozását megkezdtük.
</div>
<div class="statusdesc">
	<h3>Tisztelt Ügyfelünk!</h3>
	 Köszönjük megtisztelő bizalmát!<br><br>
	 Hitelkérelmének feldolgozását megkezdtük. A bírálat eredményéről hamarosan tájékoztatni fogjuk.
	 <br><br>
	 Probléma merült fel? Hívja az alábbi telefonszámot: <?=$this->settings['page_author_phone']?>
</div>
<br><br>
<a href="/order/<?=$this->gets[3]?>" class="btn btn-default"><i class="fa fa-angle-left"></i> Megrendelés adatlapja</a>