<div class="statusmsg stat-timeout">
	Rendelkezésre álló idő lejárt!
</div>
<div class="statusdesc">
	Időtúllépés miatt a Cetelem hiteligénylés felülete visszairányította Önt webáruházunkba.
</div>
<br><br>
<a href="/order/<?=$this->gets[3]?>" class="btn btn-default"><i class="fa fa-angle-left"></i> Megrendelés adatlapja</a>